﻿namespace Financial_Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tab = new System.Windows.Forms.TabControl();
            this.tabCalculate = new System.Windows.Forms.TabPage();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblOutput = new System.Windows.Forms.Label();
            this.btnCal = new System.Windows.Forms.Button();
            this.lblTC = new System.Windows.Forms.Label();
            this.txtTC = new System.Windows.Forms.TextBox();
            this.lblR = new System.Windows.Forms.Label();
            this.txtR = new System.Windows.Forms.TextBox();
            this.lblT = new System.Windows.Forms.Label();
            this.txtT = new System.Windows.Forms.TextBox();
            this.lblPV = new System.Windows.Forms.Label();
            this.txtPV = new System.Windows.Forms.TextBox();
            this.tabFormulas = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printReviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fontToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fontColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.marginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TxtBottomMargin = new System.Windows.Forms.ToolStripTextBox();
            this.rightToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.TxtRightMargin = new System.Windows.Forms.ToolStripTextBox();
            this.TxtTopMargin = new System.Windows.Forms.ToolStripTextBox();
            this.LeftToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TxtLeftMargin = new System.Windows.Forms.ToolStripTextBox();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.tab.SuspendLayout();
            this.tabCalculate.SuspendLayout();
            this.tabFormulas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tab
            // 
            this.tab.Controls.Add(this.tabCalculate);
            this.tab.Controls.Add(this.tabFormulas);
            this.tab.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tab.Location = new System.Drawing.Point(12, 36);
            this.tab.Name = "tab";
            this.tab.SelectedIndex = 0;
            this.tab.Size = new System.Drawing.Size(637, 402);
            this.tab.TabIndex = 0;
            // 
            // tabCalculate
            // 
            this.tabCalculate.BackgroundImage = global::Financial_Calculator.Properties.Resources.Premium_Vector___Stock_market_graph_or_forex_trading_chart_for_business_and_financial_concepts_reports_and_investment_on_dark_background_vector_illustration;
            this.tabCalculate.Controls.Add(this.btnClear);
            this.tabCalculate.Controls.Add(this.lblOutput);
            this.tabCalculate.Controls.Add(this.btnCal);
            this.tabCalculate.Controls.Add(this.lblTC);
            this.tabCalculate.Controls.Add(this.txtTC);
            this.tabCalculate.Controls.Add(this.lblR);
            this.tabCalculate.Controls.Add(this.txtR);
            this.tabCalculate.Controls.Add(this.lblT);
            this.tabCalculate.Controls.Add(this.txtT);
            this.tabCalculate.Controls.Add(this.lblPV);
            this.tabCalculate.Controls.Add(this.txtPV);
            this.tabCalculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabCalculate.Location = new System.Drawing.Point(4, 33);
            this.tabCalculate.Name = "tabCalculate";
            this.tabCalculate.Padding = new System.Windows.Forms.Padding(3);
            this.tabCalculate.Size = new System.Drawing.Size(629, 365);
            this.tabCalculate.TabIndex = 0;
            this.tabCalculate.Text = "Calculate";
            this.tabCalculate.UseVisualStyleBackColor = true;
            this.tabCalculate.Click += new System.EventHandler(this.tabCalculate_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.White;
            this.btnClear.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Blue;
            this.btnClear.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.btnClear.Location = new System.Drawing.Point(488, 301);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(105, 38);
            this.btnClear.TabIndex = 2;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblOutput
            // 
            this.lblOutput.AutoSize = true;
            this.lblOutput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(39)))), ((int)(((byte)(59)))));
            this.lblOutput.ForeColor = System.Drawing.Color.White;
            this.lblOutput.Location = new System.Drawing.Point(230, 25);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(0, 24);
            this.lblOutput.TabIndex = 10;
            // 
            // btnCal
            // 
            this.btnCal.BackColor = System.Drawing.Color.White;
            this.btnCal.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Blue;
            this.btnCal.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.btnCal.Location = new System.Drawing.Point(360, 301);
            this.btnCal.Name = "btnCal";
            this.btnCal.Size = new System.Drawing.Size(100, 38);
            this.btnCal.TabIndex = 9;
            this.btnCal.Text = "Calculate";
            this.btnCal.UseVisualStyleBackColor = false;
            this.btnCal.Click += new System.EventHandler(this.btnCal_Click);
            // 
            // lblTC
            // 
            this.lblTC.AutoSize = true;
            this.lblTC.ForeColor = System.Drawing.Color.White;
            this.lblTC.Location = new System.Drawing.Point(27, 264);
            this.lblTC.Name = "lblTC";
            this.lblTC.Size = new System.Drawing.Size(184, 24);
            this.lblTC.TabIndex = 7;
            this.lblTC.Text = "Times Compounded";
            // 
            // txtTC
            // 
            this.txtTC.Location = new System.Drawing.Point(234, 259);
            this.txtTC.Name = "txtTC";
            this.txtTC.Size = new System.Drawing.Size(100, 29);
            this.txtTC.TabIndex = 8;
            // 
            // lblR
            // 
            this.lblR.AutoSize = true;
            this.lblR.ForeColor = System.Drawing.Color.White;
            this.lblR.Location = new System.Drawing.Point(158, 207);
            this.lblR.Name = "lblR";
            this.lblR.Size = new System.Drawing.Size(48, 24);
            this.lblR.TabIndex = 5;
            this.lblR.Text = "Rate";
            // 
            // txtR
            // 
            this.txtR.Location = new System.Drawing.Point(234, 207);
            this.txtR.Name = "txtR";
            this.txtR.Size = new System.Drawing.Size(100, 29);
            this.txtR.TabIndex = 6;
            // 
            // lblT
            // 
            this.lblT.AutoSize = true;
            this.lblT.ForeColor = System.Drawing.Color.White;
            this.lblT.Location = new System.Drawing.Point(158, 152);
            this.lblT.Name = "lblT";
            this.lblT.Size = new System.Drawing.Size(53, 24);
            this.lblT.TabIndex = 3;
            this.lblT.Text = "Time";
            // 
            // txtT
            // 
            this.txtT.Location = new System.Drawing.Point(234, 152);
            this.txtT.Name = "txtT";
            this.txtT.Size = new System.Drawing.Size(100, 29);
            this.txtT.TabIndex = 4;
            // 
            // lblPV
            // 
            this.lblPV.AutoSize = true;
            this.lblPV.ForeColor = System.Drawing.Color.White;
            this.lblPV.Location = new System.Drawing.Point(75, 96);
            this.lblPV.Name = "lblPV";
            this.lblPV.Size = new System.Drawing.Size(136, 24);
            this.lblPV.TabIndex = 1;
            this.lblPV.Text = "Principal Value";
            // 
            // txtPV
            // 
            this.txtPV.Location = new System.Drawing.Point(234, 96);
            this.txtPV.Name = "txtPV";
            this.txtPV.Size = new System.Drawing.Size(100, 29);
            this.txtPV.TabIndex = 2;
            // 
            // tabFormulas
            // 
            this.tabFormulas.BackgroundImage = global::Financial_Calculator.Properties.Resources.Fresno_Azul_Oscuro_Fondo_De_Color_Sólido_3dbanner__Gris_Azul_Oscuro__Color_Solido__Estéreo_Espacial_Imagen_de_Fondo_Para_Descarga_Gratuita___Pngtreee1;
            this.tabFormulas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabFormulas.Controls.Add(this.label1);
            this.tabFormulas.Controls.Add(this.pictureBox1);
            this.tabFormulas.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabFormulas.Location = new System.Drawing.Point(4, 33);
            this.tabFormulas.Name = "tabFormulas";
            this.tabFormulas.Padding = new System.Windows.Forms.Padding(3);
            this.tabFormulas.Size = new System.Drawing.Size(629, 365);
            this.tabFormulas.TabIndex = 1;
            this.tabFormulas.Text = "Formulas";
            this.tabFormulas.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(284, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(296, 336);
            this.label1.TabIndex = 1;
            this.label1.Text = resources.GetString("label1.Text");
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Financial_Calculator.Properties.Resources.Formulas;
            this.pictureBox1.Location = new System.Drawing.Point(18, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(241, 369);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(660, 33);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printReviewToolStripMenuItem,
            this.printToolStripMenuItem,
            this.fontToolStripMenuItem,
            this.fontColorToolStripMenuItem,
            this.marginToolStripMenuItem});
            this.optionsToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(90, 29);
            this.optionsToolStripMenuItem.Text = "Options";
            // 
            // printReviewToolStripMenuItem
            // 
            this.printReviewToolStripMenuItem.Name = "printReviewToolStripMenuItem";
            this.printReviewToolStripMenuItem.Size = new System.Drawing.Size(195, 30);
            this.printReviewToolStripMenuItem.Text = "Print Preview";
            this.printReviewToolStripMenuItem.Click += new System.EventHandler(this.printReviewToolStripMenuItem_Click);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(195, 30);
            this.printToolStripMenuItem.Text = "Print";
            this.printToolStripMenuItem.Click += new System.EventHandler(this.printToolStripMenuItem_Click);
            // 
            // fontToolStripMenuItem
            // 
            this.fontToolStripMenuItem.Name = "fontToolStripMenuItem";
            this.fontToolStripMenuItem.Size = new System.Drawing.Size(195, 30);
            this.fontToolStripMenuItem.Text = "Font";
            this.fontToolStripMenuItem.Click += new System.EventHandler(this.fontToolStripMenuItem_Click);
            // 
            // fontColorToolStripMenuItem
            // 
            this.fontColorToolStripMenuItem.Name = "fontColorToolStripMenuItem";
            this.fontColorToolStripMenuItem.Size = new System.Drawing.Size(195, 30);
            this.fontColorToolStripMenuItem.Text = "Font Color";
            this.fontColorToolStripMenuItem.Click += new System.EventHandler(this.fontColorToolStripMenuItem_Click);
            // 
            // marginToolStripMenuItem
            // 
            this.marginToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToptToolStripMenuItem,
            this.TxtTopMargin,
            this.LeftToolStripMenuItem,
            this.TxtLeftMargin});
            this.marginToolStripMenuItem.Name = "marginToolStripMenuItem";
            this.marginToolStripMenuItem.Size = new System.Drawing.Size(195, 30);
            this.marginToolStripMenuItem.Text = "Margins";
            // 
            // ToptToolStripMenuItem
            // 
            this.ToptToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bottomToolStripMenuItem,
            this.TxtBottomMargin,
            this.rightToolStripMenuItem1,
            this.TxtRightMargin});
            this.ToptToolStripMenuItem.Name = "ToptToolStripMenuItem";
            this.ToptToolStripMenuItem.Size = new System.Drawing.Size(160, 30);
            this.ToptToolStripMenuItem.Text = "Top:";
            // 
            // bottomToolStripMenuItem
            // 
            this.bottomToolStripMenuItem.Name = "bottomToolStripMenuItem";
            this.bottomToolStripMenuItem.Size = new System.Drawing.Size(160, 30);
            this.bottomToolStripMenuItem.Text = "Bottom:";
            // 
            // TxtBottomMargin
            // 
            this.TxtBottomMargin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtBottomMargin.Name = "TxtBottomMargin";
            this.TxtBottomMargin.Size = new System.Drawing.Size(100, 23);
            this.TxtBottomMargin.Click += new System.EventHandler(this.TxtBottomMargin_Click);
            // 
            // rightToolStripMenuItem1
            // 
            this.rightToolStripMenuItem1.Name = "rightToolStripMenuItem1";
            this.rightToolStripMenuItem1.Size = new System.Drawing.Size(160, 30);
            this.rightToolStripMenuItem1.Text = "Right:";
            // 
            // TxtRightMargin
            // 
            this.TxtRightMargin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtRightMargin.Name = "TxtRightMargin";
            this.TxtRightMargin.Size = new System.Drawing.Size(100, 23);
            // 
            // TxtTopMargin
            // 
            this.TxtTopMargin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtTopMargin.Name = "TxtTopMargin";
            this.TxtTopMargin.Size = new System.Drawing.Size(100, 23);
            this.TxtTopMargin.Click += new System.EventHandler(this.TxtLeftMargin_Click);
            // 
            // LeftToolStripMenuItem
            // 
            this.LeftToolStripMenuItem.Name = "LeftToolStripMenuItem";
            this.LeftToolStripMenuItem.Size = new System.Drawing.Size(160, 30);
            this.LeftToolStripMenuItem.Text = "Left:";
            // 
            // TxtLeftMargin
            // 
            this.TxtLeftMargin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtLeftMargin.Name = "TxtLeftMargin";
            this.TxtLeftMargin.Size = new System.Drawing.Size(100, 23);
            this.TxtLeftMargin.Click += new System.EventHandler(this.TxtRightMargin_Click);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printDialog1
            // 
            this.printDialog1.Document = this.printDocument1;
            this.printDialog1.UseEXDialog = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(660, 450);
            this.Controls.Add(this.tab);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.tab.ResumeLayout(false);
            this.tabCalculate.ResumeLayout(false);
            this.tabCalculate.PerformLayout();
            this.tabFormulas.ResumeLayout(false);
            this.tabFormulas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tab;
        private System.Windows.Forms.TabPage tabCalculate;
        private System.Windows.Forms.TabPage tabFormulas;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblPV;
        private System.Windows.Forms.TextBox txtPV;
        private System.Windows.Forms.Label lblTC;
        private System.Windows.Forms.TextBox txtTC;
        private System.Windows.Forms.Label lblR;
        private System.Windows.Forms.TextBox txtR;
        private System.Windows.Forms.Label lblT;
        private System.Windows.Forms.TextBox txtT;
        private System.Windows.Forms.Button btnCal;
        private System.Windows.Forms.Label lblOutput;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printReviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fontToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fontColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem marginToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox TxtTopMargin;
        private System.Windows.Forms.ToolStripMenuItem LeftToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox TxtLeftMargin;
        private System.Windows.Forms.ToolStripMenuItem ToptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox TxtBottomMargin;
        private System.Windows.Forms.ToolStripMenuItem rightToolStripMenuItem1;
        private System.Windows.Forms.ToolStripTextBox TxtRightMargin;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label label1;
    }
}

