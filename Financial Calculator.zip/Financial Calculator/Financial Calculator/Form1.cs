﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Financial_Calculator
{
    public partial class Form1 : Form
    {
        private float TopMarginInches = 1f;
        private float leftMarginInches = 1.25f;
        private float BottomMarginInches = 1f;
        private float RightMarginInches = 1.25f;

        public Form1()
        {
            InitializeComponent();
            UpdateMargins();
        }
        private void UpdateMargins()
        {
            int dpi = 100; // DPI (dots per inch)
            int topMarginPixels = (int)(TopMarginInches * dpi);
            int leftMarginPixels = (int)(leftMarginInches * dpi);
            int bottomMarginPixels = (int)(BottomMarginInches * dpi);
            int rightMarginPixels = (int)(RightMarginInches * dpi);


        }
        private void ApplyMargins()
        {
            if (float.TryParse(TxtTopMargin.Text, out float top) &&
               float.TryParse(TxtLeftMargin.Text, out float left) &&
              float.TryParse(TxtBottomMargin.Text, out float bottom) &&
              float.TryParse(TxtRightMargin.Text, out float right))
            {
                // Update margin sizes
                TopMarginInches = top;
                leftMarginInches = left;
                BottomMarginInches = bottom;
                RightMarginInches = right;

                // Apply updated margins
                UpdateMargins();
            }
            else
            {
                MessageBox.Show("Please enter valid floating-point values for margins.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }



        private void btnCal_Click(object sender, EventArgs e)
        {
            decimal.TryParse(txtPV.Text, out decimal PV);
            double.TryParse(txtT.Text, out double T);
            double.TryParse(txtR.Text, out double R);
            int.TryParse(txtTC.Text, out int TC);
            if (PV >= 0 && T >= 0 && R >= 0 && TC > 0)
            {
                var dValue = PV * (decimal) Math.Pow(1 + (R / 100) / TC, TC * T);
                lblOutput.Text = $"Discrete Value: ${dValue:N2}\n";
                var cValue = PV * (decimal)Math.Pow(Math.E, R / 100 * T);
                lblOutput.Text += $"Continues Value: ${cValue:N2}";
            }
            else
                MessageBox.Show("Check your input.");
        }

        private void printReviewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowDialog();
        }

        private void fontColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (printDialog1.ShowDialog() == DialogResult.OK)
                    printDocument1.Print();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
        private void TopToolStripMenuItem_Click(object sender, EventArgs e)
        {
             string inputTopMargin = Microsoft.VisualBasic.Interaction.InputBox("Enter top margin:", "Top Margin");

            // Parse the input and set the top margin if valid
            if (int.TryParse(inputTopMargin, out int topMarginValue))
            {
                TopMarginInches = topMarginValue;
                UpdateMargins();
            }
            else if (inputTopMargin != "") // Check if user input is not empty
            {
                MessageBox.Show("Please enter a valid integer value for the top margin.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void LefttToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string inputLeftMargin = Microsoft.VisualBasic.Interaction.InputBox("Enter left margin:", "Left Margin");

            // Parse the input and set the left margin if valid
            if (int.TryParse(inputLeftMargin, out int leftMarginValue))
            {
                leftMarginInches = leftMarginValue;
                UpdateMargins();
            }
            else if (inputLeftMargin != "") // Check if user input is not empty
            {
                MessageBox.Show("Please enter a valid integer value for the left margin.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BottomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string inputBottomMargin = Microsoft.VisualBasic.Interaction.InputBox("Enter bottom margin:", "Bottom Margin");

            // Parse the input and set the bottom margin if valid
            if (int.TryParse(inputBottomMargin, out int bottomMarginValue))
            {
                BottomMarginInches = bottomMarginValue;
                UpdateMargins();
            }
            else if (inputBottomMargin != "") // Check if user input is not empty
            {
                MessageBox.Show("Please enter a valid integer value for the bottom margin.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void RightToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            string inputRightMargin = Microsoft.VisualBasic.Interaction.InputBox("Enter right margin:", "Right Margin");

            // Parse the input and set the right margin if valid
            if (int.TryParse(inputRightMargin, out int rightMarginValue))
            {
                RightMarginInches = rightMarginValue;
                UpdateMargins();
            }
            else if (inputRightMargin != "") // Check if user input is not empty
            {
                MessageBox.Show("Please enter a valid integer value for the right margin.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }




        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            if (tab.SelectedTab == tabFormulas)
            {
     
                int.TryParse(ToptToolStripMenuItem.Text, out int left);
                int.TryParse(LeftToolStripMenuItem.Text, out int right);
                if (left >= 0 && right >= 0)
                    e.Graphics.DrawImage(pictureBox1.Image, new Point(left, right));
                else
                    e.Graphics.DrawImage(pictureBox1.Image, new Point(10, 10));


            }
            else
            {
                string txtToPrint = $"PV:{txtPV.Text}\n" +
                 $"T:{txtT.Text}\n" +
                 $"R:{txtR.Text}\n" +
                 $"TC:{txtTC.Text}\n" +
                 lblOutput.Text;
                e.Graphics.DrawString(txtToPrint, fontDialog1.Font,
                    new SolidBrush(colorDialog1.Color), e.MarginBounds);

            }
        }

        private void TxtTopMargin_Click(object sender, EventArgs e)
        {
            ApplyMargins();

        }
        private void TxtLeftMargin_Click(object sender, EventArgs e)
        {
            ApplyMargins();


        }

        private void TxtBottomMargin_Click(object sender, EventArgs e)
        {
            ApplyMargins();
        }

        private void TxtRightMargin_Click(object sender, EventArgs e)
        {
            ApplyMargins();
        }

        private void btnClear_Click(object sender, EventArgs e) 
        {
            txtPV.Text = "";
            txtT.Text = "";
            txtR.Text = "";
            txtTC.Text = "";

            // Clear output label
            lblOutput.Text = "";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tabCalculate_Click(object sender, EventArgs e)
        {

        }
    }
}
